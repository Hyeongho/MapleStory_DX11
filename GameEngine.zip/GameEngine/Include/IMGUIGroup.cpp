#include "IMGUIGroup.h"

CIMGUIGroup::CIMGUIGroup()
{
}

CIMGUIGroup::~CIMGUIGroup()
{
}

bool CIMGUIGroup::Init()
{
    return true;
}

void CIMGUIGroup::Render()
{
}
