#include "IMGUIRadio.h"

CIMGUIRadio::CIMGUIRadio()
{
}

CIMGUIRadio::~CIMGUIRadio()
{
}

bool CIMGUIRadio::Init()
{
	return true;
}

void CIMGUIRadio::Render()
{
}
