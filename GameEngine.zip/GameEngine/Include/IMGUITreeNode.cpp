#include "IMGUITreeNode.h"

CIMGUITreeNode::CIMGUITreeNode()
{
}

CIMGUITreeNode::~CIMGUITreeNode()
{
}

bool CIMGUITreeNode::Init()
{
	return true;
}

void CIMGUITreeNode::Render()
{
}
